#ifndef OOPproject_ATTRIBUTEDNODE1_H
#define OOPproject_ATTRIBUTEDNODE1_H
class AttributedNode1{
    char gen;
    int age;
public:
    AttributedNode1();
    void setgen(char a);
    void setage(int a);
    char getgen()const;
    int getage()const;
    ~AttributedNode1();
};


#endif //OOPproject_ATTRIBUTEDNODE1_H
